package com.solodroid.ecommerce;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class pak_sweets extends Activity {

    Button btn_1, btn_2, btn_3, btn_4;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pak_sweets);

        btn_1 = (Button) findViewById(R.id.button2);
        btn_2 = (Button) findViewById(R.id.button5);
        btn_3 = (Button) findViewById(R.id.button4);
        btn_4 = (Button) findViewById(R.id.button6);

        btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Added to Cart", Toast.LENGTH_SHORT).show();
            }
        });

        btn_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Added to Cart", Toast.LENGTH_SHORT).show();
            }
        });

        btn_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Added to Cart", Toast.LENGTH_SHORT).show();
            }
        });

        btn_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Added to Cart", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
