package com.solodroid.ecommerce;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;

public class ActivityCategoryList extends Activity {
	
	GridView listCategory;
	ProgressBar prgLoading;
	TextView txtAlert;

	ImageView pak_sweets, turk_sweets, beverages, snacks;

	// declare adapter object to create custom category list
	AdapterCategoryList cla;
	
	// create arraylist variables to store data from server
	static ArrayList<Long> Category_ID = new ArrayList<Long>();
	static ArrayList<String> Category_name = new ArrayList<String>();
	static ArrayList<String> Category_image = new ArrayList<String>();
	
	String CategoryAPI;
	int IOConnect = 0;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.category_list);
        
        ActionBar bar = getActionBar();
        bar.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.header)));
        bar.setDisplayHomeAsUpEnabled(true);
        bar.setHomeButtonEnabled(true);
        bar.setTitle("Category");

        pak_sweets = (ImageView) findViewById(R.id.paksweets);
		turk_sweets = (ImageView) findViewById(R.id.imageView7);
		beverages = (ImageView) findViewById(R.id.imageView8);
		snacks = (ImageView) findViewById(R.id.imageView11);

        prgLoading = (ProgressBar) findViewById(R.id.prgLoading);
        listCategory = (GridView) findViewById(R.id.listCategory);
        txtAlert = (TextView) findViewById(R.id.txtAlert);
        

		pak_sweets.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent I = new Intent(ActivityCategoryList.this, pak_sweets.class);
				startActivity(I);
			}
		});

		turk_sweets.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent I = new Intent(ActivityCategoryList.this, turk_sweets.class);
				startActivity(I);
			}
		});

		beverages.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent I = new Intent(ActivityCategoryList.this, beverages.class);
				startActivity(I);
			}
		});

		snacks.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent I = new Intent(ActivityCategoryList.this, snacks.class);
				startActivity(I);
			}
		});
    }
}
